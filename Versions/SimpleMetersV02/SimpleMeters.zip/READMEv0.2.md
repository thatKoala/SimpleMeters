# SimpleMeters v0.2

## Patch Notes

This update focuses on making the addon smoother, more reliable, and easier to trust during longer sessions.

- Your meter data is now saved more safely, so totals are much less likely to be lost after a crash, `/reload`, or normal game exit.
- Total damage display has been optimized to feel smoother on screen during busy fights.
- Total combat time calculation has been improved for more accurate DPS over full runs.
- Fight timing and damage updates have been tightened to reduce odd dips after packs die.
- General cleanup and performance tweaks were applied to keep the addon lightweight and responsive.

Thank you for testing and feedback.

## Package Integrity

- `SimpleMeters.zip` SHA-256: `c55d3bbca6cafdd612c5e6f009b1a51a7066ab3cbd35b0eaa21b170e85821ec9`
